def print_info():
    print("학과 : 사이버보안")
    print("학번 : 2467001")
    print("이름 : 강다은")
